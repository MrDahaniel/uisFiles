f = @(x)1-((1/40)*x)-((1/8)*x^2);
l = 0;
u = 2.5;
t = 1;
r = 5000;
fixedPointV2(f,l,u,t,r)