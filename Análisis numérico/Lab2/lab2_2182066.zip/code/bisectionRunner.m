f = @(x)x^2-x-1;
lowerBracket = 1;
upperBracket = 6;
ite = 100;
bisection(f,lowerBracket,upperBracket,ite)