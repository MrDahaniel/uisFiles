f = @(x)(tan(x)^2)-x;
lowerBracket = 2;
upperBracket = 3;
ite = 200;
explicitBisection(f,lowerBracket,upperBracket,ite)