syms x

dom = linspace(-3, 7);

orig = @(x) 3 * sin(pi*x/6);

inter = matlabFunction((3*3^(1/2)*x*(x/2 - 2)*(x - 1)*(x - 3))/4 - x*(x/2 - 1/2)*(x - 2)*(x - 4) - (3*x*(x/2 - 3/2)*(x/3 - 4/3)*(x - 2))/2 + (3*3^(1/2)*x*(x/2 - 1)*(x/3 - 1/3)*(x - 3))/8);


plot(dom, inter(dom))
hold on
plot(dom, orig(dom))
hold on
axis([-3, 7, -4, 4])
line([0,0], ylim, 'Color', 'k', 'LineWidth', 2)
line(xlim, [0,0], 'Color', 'k', 'LineWidth', 2) 
grid on

plot(0,orig(0),'*')
plot(1,orig(1),'*')
plot(2,orig(2),'*')
plot(3,orig(3),'*')
plot(4,orig(4),'*')
