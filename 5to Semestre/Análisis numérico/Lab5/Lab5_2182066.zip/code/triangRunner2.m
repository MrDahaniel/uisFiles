A = [1 2 -3 4; 4 8 12 -8; 2 3 2 1; -3 -1 1 -4];

B = [3; 60; 1; 5];

triangularASolver(A, B) 
