APro = [1 1 1; 1 -1 -1; 1 1 -13];
BPro = [70; 0; 0];

triangularBSolver(APro, BPro)