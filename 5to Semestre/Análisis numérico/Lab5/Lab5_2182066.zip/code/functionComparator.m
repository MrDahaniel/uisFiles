A = [3, 5, 6; 7, 7, 1; 3, 8, 9];

[mL, mU] = lu(A)
[L, U] = luFact(A)